public class AutoClasico extends Vehiculo {

    String marca;
    String modelo;
    String color;
    Double precio;
    Radio radio;

    // un auto clasico se puede fabricar sin radio despues se le agrega radio

    public AutoClasico(String marca, String modelo, String color, Double precio) {
        super(marca, modelo, color, precio);
    }

    // un auto clasico con radio
    public AutoClasico(String marca, String modelo, String color, Double precio, String marcaRadio, Double potencia) {
        super(marca, modelo, color, precio, marcaRadio, potencia);
    }

    @Override
    public String toString() {
        return "Auto Clasico " + super.toString();
    }

    @Override
    void agregarRadio() {
        // radio = new Radio(super.setRadio(radio));
    }

    @Override
    public void setRadio(String marcaRadio, Double potencia) {

        super.setRadio(marcaRadio, potencia);
    }

}
