public class AutoNuevo extends Vehiculo {
    String marca;
    String modelo;
    String color;
    Double precio;
    Radio radio;
    // auto nuevo siempre tiene radio

    public AutoNuevo(String marca, String modelo, String color, Double precio, String marcaRadio, Double potencia) {
        super(marca, modelo, color, precio, marcaRadio, potencia);
    }

    @Override
    public String toString() {
        return "Auto Nuevo " + super.toString();
    }

    @Override
    void agregarRadio() {

    }

}
