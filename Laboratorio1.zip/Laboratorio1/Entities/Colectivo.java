public final class Colectivo extends Vehiculo {

    public Colectivo(String marca, String modelo, String color, Double precio) {
        super(marca, modelo, color, precio);
    }

    @Override
    public String toString() {
        return "Colectivo " + super.toString();
    }

    @Override
    void agregarRadio() {

    }

}